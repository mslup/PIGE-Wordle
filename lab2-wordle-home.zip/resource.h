﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by lab2.rc
//
#define IDC_MYICON                      2
#define IDD_LAB2_DIALOG                 102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDS_KEYBOARD_TITLE              103
#define IDM_ABOUT                       104
#define IDS_APP_SECOND                  104
#define IDS_PUZZLE_TITLE                104
#define IDM_EXIT                        105
#define IDC_LAB2                        109
#define IDR_MAINFRAME                   128
#define IDI_LAB2                        130
#define IDI_SMALL                       131
#define ID_DIFFICULTY_MEDIUM            32771
#define ID_DIFFICULTY_HARD              32772
#define IDM_EASy                        32773
#define IDM_Ehdh                        32774
#define solution                        32775
#define ID_DIFFICULTY_EASY              32776
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
