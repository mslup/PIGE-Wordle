#pragma once

#include <windows.h>
#include <tchar.h>
#include <utility>
#include <string>
#include <stdexcept>
#include <array>
#include <set>
#include <algorithm>
#include <iostream>
#include <fstream>

#include "resource.h"

#define MAX_LOADSTRING 100
#define PUZZLEWINDOW_COUNT 4

#include "window.h"
#include "wordle.h"